export class Doctor{
    id:number
    fname:string;
    lname:string;
    experience:number;
    mail:string;
    specialist:string;
    password:string;
}