export class Medicine {
    mid: number;
    quantity: number;
    medname:string;
}
 
