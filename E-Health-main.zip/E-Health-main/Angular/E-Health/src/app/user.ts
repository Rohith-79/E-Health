export class User{
    id:number;
    email:string;
    username:string;
    password:string;
    re_password:string;
    number:string;
    address:string;
    constructor()
    {
    }

}