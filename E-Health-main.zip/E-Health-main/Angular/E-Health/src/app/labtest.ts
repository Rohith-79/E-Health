export class Labtest {
    lid:number;
    testname:string;
 
}