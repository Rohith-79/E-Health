export class Prescription{
    pid:number;
    labtest:string;
    medicine:string;
    constructor()
    {
    }
}