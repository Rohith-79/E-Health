export class Appointment {
    id: number;
    patientName: string;
    doctorName: string;
    date: string;
    age:number;
    gender: string;
    description: string;
    contact: string;
}
