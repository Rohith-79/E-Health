# Hospital-Management

Hospital Management System(HMS) is a system for managing the hospital functions and events. It has different modules such as adding new doctors, managing parents and managing appointments. It is a web-based powerful hospital management containing user and admin panel.

#Technologies Used

-->SpringBoot
-->JDK 11
-->Embedded Apache Tomcat 
-->SpringTool Suite Editor

#Front end

-->Angular 6
-->Bootstrap for responsive webpages
-->Vs code editor

#Databases

-->Hibernate+Jpa




#Pre-requistes before executing

-->Clone the project
-->change the database properties in "application.properties" file in springboot
-->configure the server port numbers
-->Run
